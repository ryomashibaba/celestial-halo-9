# R33-S21 GitHub Upload Package — reference only

This is a REDUCED TRANSPORT PACKAGE, not the bitwise-identical original C55-C ZIP.
The original C55-C GLB, camera JSON, design and source code are included without modification, as is the S18 study GLB.
High-resolution reference renders and rejected-iteration assets were excluded solely to fit GitHub browser's per-file upload limit; a resized contact preview is included.
Original C55-C source ZIP SHA256: d3ec70db4a925e5974a159d47263be969f685ce7bc2777da1540c880374e1f5c
Use only in isolated R33-S21 research; no formal adoption, Minecraft, or main changes.
