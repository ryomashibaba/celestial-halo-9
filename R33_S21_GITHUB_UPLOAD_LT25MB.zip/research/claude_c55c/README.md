# C55-C《無端渓結 / ENDLESS-GORGE KNOT》— Claude 独立研究（判定: ART HOLD・正式採択0件）
CELESTIAL HALO-9 中央巨大建築研究 C55-C。C55-B《聖脊昇階大伽藍》（歴史的聖堂のSF化に見える）からマクロ造形の思想を転換した実3D。
**未達が多い研究成果であり、正式中央美術ではない。** 詳細は `ART_SELF_ASSESSMENT.md`。

## 構想（1行）
都市そのものが構造体となる、連続した一本の渓谷都市リボン（全長33.4km）が、浮遊する三葉結びを描く。階段状テラスの渓谷が上向き・内向き・下向きに回り、頭上に逆さの都市が垂れる。内部ホール3基、衛星リボン6本、地上は対数螺旋腕の街区。

## ファイル
| パス | 内容 |
|---|---|
| `model/C55C_endless_gorge_knot.glb` | 実3D（158.9万三角形、40.6MB、Z-up→glTF Y-upで書出）。窓・発光・空・霧はGLBに含まれない |
| `renders/01〜12_*.png`, `_contact.png` | 12視点（遠景・正面・側面・背面・俯瞰・地上・街路・渓谷・内部ホール・高高度・逆光）。1600×900・自作ラスタライザ |
| `validation/C55C_validation.json` | 寸法・三角形内訳・干渉クリアランス・GLB検証・レンダ統計 |
| `validation/C55C_cameras.json` | 12カメラ（重力方向のup付き） |
| `code/` | 生成・レンダ・検証コード一式（numpy/scipy/skimage/cv2。**このコードだけで同一シーンを再生成できる**ことを確認） |
| `code/blender_import_UNTESTED.py` | Blender取り込み（未検証）。`.blend` は未生成 |
| `rejected/` | 却下したレンズ案・細リボン試作のコードと画像 |
| `DESIGN_C55C.md` `STATUS_REPORT.md` `ART_SELF_ASSESSMENT.md` `UNRESOLVED_AND_NEXT.md` `REJECTED_ITERATIONS.md` `LATEST_STATE.md` | 設計・実績・評価・未解決・失敗記録・次チャット用状態 |
| `push_to_github.sh` | 新規ブランチへの保存（ダミーremoteでのみ試験。実GitHub未実行） |

## 再生成（作業フォルダ=code/）
```
mkdir -p out final
python3 build_scene.py                          # scene_c55c.npz / frame_c55c.npz / parts.json / knot_field.npz
python3 export_glb.py out/C55C_endless_gorge_knot.glb
python3 views.py 1600 900 2 final               # 12視点 (約30〜45秒/視点, 1CPU)
python3 validate.py                             # out/validation/*.json
```
## 制約
main・Freeze・正式原本は未変更 / 正式中央美術採択 0件 / Minecraft施工 HOLD / GPT側ブランチ(J7-R30, Draft PR #63)は未変更 / CITY MASTER 3D FIRST 維持(10km全域の詳細3Dは未達)。
