import numpy as np, json, sys, time, cv2
import render, raster
fr=np.load('frame_c55c.npz'); P,T,U,B,w,R=fr['P'],fr['T'],fr['U'],fr['B'],fr['w'],fr['R']
meta=json.load(open('parts.json')); halls=meta['halls']
def at(i,du=8.,db=0.,ahead=0.,up=0.,fov=70):
    pos=P[i]+U[i]*du+B[i]*db; tgt=P[i]+T[i]*(900+ahead)+U[i]*(du+up)+B[i]*db
    return dict(pos=tuple(pos),tgt=tuple(tgt),fov=fov)
n_=len(P); hall_mask=np.zeros(n_,bool)
for (i0,wn,_) in halls:
    for j in range(int(i0)-30,int(i0)+int(wn)+30): hall_mask[j%n_]=True
# gravity-consistent camera: up = gorge normal U
def gcam(i,du=40.,db=0.,look=900.,dwn=0.,fov=72,side=0.):
    pos=P[i]+U[i]*du+B[i]*db; tgt=P[i]+T[i]*look+U[i]*(du+dwn)+B[i]*(db+side)
    return dict(pos=tuple(pos),tgt=tuple(tgt),fov=fov,up=tuple(U[i]))
upr=np.where((U[:,2]>0.75)&(~hall_mask))[0]
i_open=int(upr[len(upr)//2]) if len(upr) else 900
hm=[(float(U[(int(h[0])+np.arange(int(h[1])))%n_,2].mean()),int(h[0]),int(h[1])) for h in halls]; hm.sort(reverse=True)
i_hall=hm[0][1]+hm[0][2]//3
i_wall=int(upr[len(upr)//3]) if len(upr) else 760
V={
 '01_far_whole':dict(pos=(-10200,-7600,420),tgt=(0,0,2450),fov=40),
 '02_front_south':dict(pos=(0,-9800,1300),tgt=(0,0,2450),fov=46),
 '03_side_east':dict(pos=(9800,300,1500),tgt=(0,0,2450),fov=46),
 '04_back_north':dict(pos=(300,9800,1100),tgt=(0,0,2450),fov=46),
 '05_aerial_top':dict(pos=(0,-2600,8800),tgt=(0,0,2000),fov=52),
 '06_ground_up_oculus':dict(pos=(800,-600,6),tgt=(0,0,2500),fov=64),
 '07_city_street_layers':dict(pos=(3000,-4200,70),tgt=(0,0,2250),fov=48),
 '08_gorge_street_open':gcam(i_open,du=36,db=-40,look=1100,dwn=-8,fov=74),
 '09_interior_hall':gcam(i_hall,du=70,db=0,look=1300,dwn=20,fov=80),
 '10_gorge_terrace_wall':dict(pos=tuple(P[i_wall]+U[i_wall]*230-B[i_wall]*w[i_wall]*0.10-T[i_wall]*500),tgt=tuple(P[i_wall]+B[i_wall]*w[i_wall]*0.30+U[i_wall]*R[i_wall]*0.45+T[i_wall]*500),fov=66,up=tuple(U[i_wall])),
 '11_highaltitude_gorge_city':dict(pos=tuple(P[i_open]-T[i_open]*1100+U[i_open]*520+B[i_open]*w[i_open]*0.1),tgt=tuple(P[i_open]+T[i_open]*800-U[i_open]*120),fov=64,up=tuple(U[i_open])),
 '12_dusk_backlit':dict(pos=(6800,8600,700),tgt=(0,0,2450),fov=44),
}
if __name__=="__main__":
    W,H=int(sys.argv[1]),int(sys.argv[2]); ss=int(sys.argv[3]); out=sys.argv[4]; sel=sys.argv[5:] or list(V)
    S=render.Scene('scene_c55c.npz'); LF=render.LensField(); stats={}
    for k in sel:
        v=V[k]; cam=raster.Camera(v['pos'],v['tgt'],v['fov'],W,H,up=v.get('up',(0,0,1)))
        t=time.time(); img=render.render(cam,S,LF,ss=ss,log=lambda *a:None); dt=time.time()-t
        cv2.imwrite(f'{out}/{k}.png',img); stats[k]=dict(pos=[round(float(x),1) for x in v['pos']],target=[round(float(x),1) for x in v['tgt']],fov=v['fov'],res=[W,H],ss=ss,sec=round(dt,1))
        print(k,round(dt,1),flush=True)
    json.dump(stats,open(f'{out}/_render_stats_{int(time.time())}.json','w'),indent=1)
