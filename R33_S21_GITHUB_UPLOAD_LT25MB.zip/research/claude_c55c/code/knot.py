"""C55-C: ENDLESS-GORGE KNOT (無端渓結). Trefoil-on-torus ribbon with terraced gorge section, hull keel, city instancing."""
import numpy as np
from geo import *
RM,RT,ZC=1950.,1150.,2650.
NT,NL=1500,121
NSTEP=6; S0=0.34; SHARP=0.20
_SC=None
def _compute_scale(n=3000,nseg=12,d0=700.,d1=1900.,floor=0.58):
    from scipy.spatial import cKDTree
    t=np.linspace(0,2*np.pi,n,endpoint=False); P=frame(t)[0]
    seg=np.arange(n)*nseg//n; trees=[cKDTree(P[seg==k]) for k in range(nseg)]
    dc=np.full(n,1e9)
    for k in range(nseg):
        dseg=np.minimum((seg-k)%nseg,(k-seg)%nseg); ok=dseg>=2
        d,_=trees[k].query(P[ok]); dc[ok]=np.minimum(dc[ok],d)
    sc=np.clip((dc-d0)/(d1-d0),0,1); sc=floor+(1-floor)*sc*sc*(3-2*sc)
    k=np.exp(-0.5*(np.arange(-60,61)/22.)**2); k/=k.sum()
    sc=np.convolve(np.concatenate([sc[-60:],sc,sc[:60]]),k,mode='same')[60:-60]
    return t,sc
def prox(t):
    global _SC
    if _SC is None: _SC=_compute_scale()
    return np.interp(np.asarray(t)%(2*np.pi),_SC[0],_SC[1],period=2*np.pi)
def wfun(t): return 1200.*(1+0.12*np.sin(3*t+0.5)+0.05*np.sin(7*t+1.2))*prox(t)**0.55
def rwall(t): return 500.*(1+0.16*np.sin(2*t+2.0))*prox(t)
def keel(t): return 380.*(1+0.16*np.sin(4*t+0.9))*prox(t)
def roll(t): return 0.30*np.sin(2*t+0.3)
TILT=np.radians(9.0)
def curve(t):
    u,v=2*t,3*t+0.35*np.sin(t+0.6)
    Rm=RM*(1+0.10*np.cos(u-0.9)); rt=RT*(1+0.08*np.sin(u+1.7))
    P=np.stack([(Rm+rt*np.cos(v))*np.cos(u),(Rm+rt*np.cos(v))*np.sin(u),rt*np.sin(v)],1)
    U=np.stack([np.cos(v)*np.cos(u),np.cos(v)*np.sin(u),np.sin(v)],1)
    return P,U
def Rx(a): c,s=np.cos(a),np.sin(a); return np.array([[1,0,0],[0,c,-s],[0,s,c]])
def frame(t):
    P,U=curve(t); h=1e-4
    T=(curve(t+h)[0]-curve(t-h)[0]); T/=np.linalg.norm(T,axis=1,keepdims=True)
    U=U-(U*T).sum(1,keepdims=True)*T; U/=np.linalg.norm(U,axis=1,keepdims=True)
    B=np.cross(U,T)
    r=roll(t)[:,None]; U2=U*np.cos(r)+B*np.sin(r); B2=np.cross(U2,T)    # roll about T
    M=Rx(TILT)
    return P@M.T+np.array([0,0,ZC]),T@M.T,U2@M.T,B2@M.T
def stair(x,k,sharp):
    y=np.clip(x,0,1)*k; i=np.floor(y); f=y-i
    h=(i+sstep(0,sharp,f)+0.05*np.clip(f-sharp,0,1))/k
    return np.where(x>=1,1.0,h)
def top_profile(l,R):
    s=np.abs(l); x=(s-S0)/(1-S0)
    return np.where(s<S0,0.0,R*stair(x,NSTEP,SHARP))
def bot_profile(l,K): return -(K*np.clip(1-l*l,0,1)**0.8+22.)
def build_ribbon():
    t=np.linspace(0,2*np.pi,NT,endpoint=False)
    P,T,U,B=frame(t); w=wfun(t); R=rwall(t); K=keel(t)
    l=np.linspace(-1,1,NL)
    arcs=np.concatenate([[0],np.cumsum(np.linalg.norm(np.roll(P,-1,0)-P,axis=1))[:-1]])
    topn=top_profile(l[None,:],R[:,None]); botn=bot_profile(l[None,:],K[:,None])
    topn[:,0]=topn[:,-1]=R*1.0; botn[:,0]=botn[:,-1]=-22.
    lat=l[None,:]*w[:,None]/2
    Vt=P[:,None,:]+B[:,None,:]*lat[...,None]+U[:,None,:]*topn[...,None]
    Vb=P[:,None,:]+B[:,None,:]*lat[...,None]+U[:,None,:]*botn[...,None]
    V=np.concatenate([Vt,Vb],1).reshape(-1,3); K2=2*NL
    # steepness attr
    dl=np.gradient(lat,axis=1); slope=np.abs(np.gradient(topn,axis=1)/np.maximum(np.abs(dl),1e-3))
    steep=np.clip(slope/0.9,0,1)
    A=np.zeros((NT,K2,2),np.float32); A[:,:NL,0]=steep; A[:,:,1]=arcs[:,None]
    idx=lambda i,j:(i%NT)*K2+j
    F=[];M=[]
    ii=np.arange(NT)[:,None]; jj=np.arange(NL-1)[None,:]
    for off,mat in ((0,6),(NL,0)):
        a=idx(ii,off+jj);b=idx(ii,off+jj+1);c=idx(ii+1,off+jj);d=idx(ii+1,off+jj+1)
        f1=np.stack([a,b,d],-1).reshape(-1,3);f2=np.stack([a,d,c],-1).reshape(-1,3)
        F+=[f1,f2];M+=[np.full(len(f1)+len(f2),mat)] if False else [np.full(len(f1),mat),np.full(len(f2),mat)]
    for e in (0,NL-1):
        a=idx(np.arange(NT),e);b=idx(np.arange(NT),NL+e);c=idx(np.arange(NT)+1,e);d=idx(np.arange(NT)+1,NL+e)
        F+=[np.stack([a,b,d],1),np.stack([a,d,c],1)];M+=[np.zeros(NT),np.zeros(NT)]
    F=np.concatenate(F).astype(np.int32);M=np.concatenate(M).astype(np.int8)
    N=vnormals(V.astype(np.float32),F)
    C=np.zeros((len(V),3),np.float32)
    C.reshape(NT,K2,3)[:,:NL]=np.array([0.034,0.032,0.036]); C.reshape(NT,K2,3)[:,NL:]=np.array([0.016,0.018,0.027])
    return V.astype(np.float32),F,M,N,C,A.reshape(-1,2),dict(t=t,P=P,T=T,U=U,B=B,w=w,R=R,K=K,arcs=arcs,length=float(arcs[-1]+np.linalg.norm(P[0]-P[-1])))
def cityscape(fr,rng,spacing=30.):
    t=fr['t'];P,T,U,B,w,R,arcs=fr['P'],fr['T'],fr['U'],fr['B'],fr['w'],fr['R'],fr['arcs']
    Ltot=fr['length']; n_st=int(Ltot/spacing)
    sg=np.linspace(0,Ltot,n_st,endpoint=False)+rng.uniform(-8,8,n_st)
    tt=np.interp(sg,np.append(arcs,Ltot),np.append(t,2*np.pi))
    Pi=np.stack([np.interp(tt,t,P[:,k],period=2*np.pi) for k in range(3)],1)
    Ti,Ui,Bi=[np.stack([np.interp(tt,t,X[:,k],period=2*np.pi) for k in range(3)],1) for X in (T,U,B)]
    for X in (Ti,Ui,Bi): X/=np.linalg.norm(X,axis=1,keepdims=True)
    wi=np.interp(tt,t,w,period=2*np.pi);Ri=np.interp(tt,t,R,period=2*np.pi)
    cent=[];axs=[];hf=[];col=[];seed=[];dens=[];lvl=[];tpar=[]
    rows=[(-0.20,0),(0.20,0),(-0.10,0),(0.10,0)]
    # floor columns: lateral fraction centers; terrace treads
    tread_c=[S0+(1-S0)*(k+0.55)/NSTEP for k in range(NSTEP)]
    cols=[(-1,0.17,0.0),(1,0.17,0.0),(-1,0.27,0.0),(1,0.27,0.0)]+[(sg_,c,k+1) for k,c in enumerate(tread_c) for sg_ in (-1,1)]
    for (sgn,lf,k) in cols:
        for i in range(n_st):
            pr=0.78 if k==0 else 0.62
            if rng.random()>pr: continue
            lm=sgn*lf*wi[i]/2+rng.uniform(-6,6)
            ln=lm/(wi[i]/2)
            topn=top_profile(np.array([abs(ln)]),np.array([Ri[i]]))[0]
            if k==0:
                lenT=rng.uniform(16,48); wid=rng.uniform(20,60)*(1.1 if lf>0.2 else 0.9); hgt=np.exp(rng.normal(np.log(60),0.55)); hgt=min(hgt,200)
            else:
                lenT=rng.uniform(14,38); wid=rng.uniform(16,34); hgt=np.exp(rng.normal(np.log(28),0.5)); hgt=min(hgt,90,Ri[i]-topn+10)
            c=Pi[i]+Bi[i]*lm+Ui[i]*(topn+hgt/2-2)
            ax=np.stack([Ti[i],Bi[i],Ui[i]]); cent.append(c);axs.append(ax);hf.append([lenT/2,wid/2,hgt/2])
            g=rng.uniform(0.10,0.17); col.append([g*1.0,g*0.97,g*0.95]);seed.append(rng.random());dens.append(rng.uniform(0.30,0.80)*(1.0 if k==0 else 0.8));lvl.append(k);tpar.append(tt[i])
    cent=np.array(cent,np.float32);axs=np.array(axs,np.float32);hf=np.array(hf,np.float32)
    import clearance
    topc=cent+axs[:,2,:]*hf[:,2:3]
    fo=clearance.f_other(topc.astype(np.float64),np.array(tpar))
    keep=fo>70.
    print('  boxes dropped near other strands:',int((~keep).sum()))
    cent,axs,hf=cent[keep],axs[keep],hf[keep]
    col=np.array(col,np.float32)[keep];seed=np.array(seed,np.float32)[keep];dens=np.array(dens,np.float32)[keep];lvl=np.array(lvl)[keep]
    return boxes(cent,axs,hf,col,seed,dens),len(cent),lvl
def canal(fr):
    t=fr['t'];P,U,B=fr['P'],fr['U'],fr['B']
    a=P+U*1.5; V=np.concatenate([a-B*13,a+B*13]).reshape(2,-1,3).transpose(1,0,2).reshape(-1,3)
    n=len(t); i=np.arange(n); 
    F=np.concatenate([np.stack([2*i,2*i+1,2*((i+1)%n)+1],1),np.stack([2*i,2*((i+1)%n)+1,2*((i+1)%n)],1)])
    return V.astype(np.float32),F.astype(np.int32)
def keel_fins(fr,rng):
    t=fr['t'];P,U,B,K,arcs=fr['P'],fr['U'],fr['B'],fr['K'],fr['arcs']
    n=len(t); hfin=150*np.clip(0.55+0.55*np.sin(11*t+0.4)+0.35*np.sin(23*t),0,1.6)
    top=P-U*(K+22-6)[:,None]; bot=top-U*hfin[:,None]
    V=np.stack([top,bot],1).reshape(-1,3); i=np.arange(n); j=(i+1)%n
    F=np.concatenate([np.stack([2*i,2*i+1,2*j+1],1),np.stack([2*i,2*j+1,2*j],1)])
    # glow edge strip along the bottom: mat 4 thin quads (same indices, scaled later)
    return V.astype(np.float32),F.astype(np.int32),bot

def ribs(V,N,every=38,width=4,off=16.):
    Vg=V.reshape(NT,2*NL,3)[:,NL:];Ng=N.reshape(NT,2*NL,3)[:,NL:]
    Vo=[];F=[];n0=0
    for st in range(0,NT,every):
        rows=[(st+k)%NT for k in range(width)]
        P=Vg[rows]+Ng[rows]*off          # width,NL,3
        base=n0; Vo.append(P.reshape(-1,3))
        for a in range(width-1):
            for j in range(NL-1):
                i0=base+a*NL+j; F+= [[i0,i0+1,i0+NL+1],[i0,i0+NL+1,i0+NL]]
        n0+=width*NL
        for a in (0,width-1):                      # side walls hull->offset
            H=Vg[rows[a]]; Po=P[a]; k0=n0
            Vo.append(H); 
            for j in range(NL-1):
                o=base+a*NL+j; h=k0+j; F+=[[h,h+1,o+1],[h,o+1,o]]
            n0+=NL
    return np.concatenate(Vo).astype(np.float32),np.array(F,np.int32)
def slabs(fr,rng,every=1300.):
    t=fr['t'];P,T,U,B,w,R,arcs=fr['P'],fr['T'],fr['U'],fr['B'],fr['w'],fr['R'],fr['arcs']
    Ltot=fr['length']; sg=np.arange(every*0.5,Ltot,every); tt=np.interp(sg,np.append(arcs,Ltot),np.append(t,2*np.pi))
    I=lambda X:np.stack([np.interp(tt,t,X[:,k],period=2*np.pi) for k in range(3)],1)
    Pi,Ti,Ui,Bi=I(P),I(T),I(U),I(B)
    for X in (Ti,Ui,Bi): X/=np.linalg.norm(X,axis=1,keepdims=True)
    wi=np.interp(tt,t,w,period=2*np.pi);Ri=np.interp(tt,t,R,period=2*np.pi)
    zh=0.66*Ri
    c=Pi+Ui*zh[:,None]; ax=np.stack([Ti,Bi,Ui],1); half=np.stack([np.full(len(tt),38.),wi*0.50,np.full(len(tt),16.)],1)
    cl=Pi+Ui*(zh-17)[:,None]; halfl=np.stack([np.full(len(tt),33.),wi*0.46,np.full(len(tt),2.5)],1)
    return (c,ax,half),(cl,ax,halfl)

def roof_profile(l,R): return R+210.*np.clip(1-l*l,0,1)**0.7
def pick_halls(fr,nhall=3,length=2300.):
    import clearance
    t=fr['t'];P,U,R=fr['P'],fr['U'],fr['R']; arcs=fr['arcs']; n=len(t)
    Q=P+U*(R[:,None]+260.)
    fo=clearance.f_other(Q.astype(np.float64),t)
    w=int(length/(fr['length']/n)); halls=[]
    score=np.array([fo[(np.arange(i,i+w))%n].min() for i in range(n)])
    for _ in range(nhall):
        i=int(np.argmax(score)); halls.append((i,w,float(score[i])))
        for j in range(i-w-60,i+w+60): score[j%n]=-1e9
    return halls
def roofs(fr,halls,rng,NLR=49):
    t=fr['t'];P,T,U,B,w,R=fr['P'],fr['T'],fr['U'],fr['B'],fr['w'],fr['R']; n=len(t)
    V=[];F=[];n0=0;l=np.linspace(-1,1,NLR)
    for (i0,wn,_) in halls:
        rows=np.arange(i0,i0+wn)%n
        topn=roof_profile(l[None,:],R[rows][:,None]); lat=l[None,:]*w[rows][:,None]/2
        Vh=P[rows][:,None,:]+B[rows][:,None,:]*lat[...,None]+U[rows][:,None,:]*topn[...,None]
        # perforations in (row,lm) space
        holes=[(rng.uniform(8,wn-8),rng.uniform(-0.62,0.62),rng.uniform(3.0,7.0),rng.uniform(0.035,0.075)) for _ in range(11)]
        keepq=np.ones((wn-1,NLR-1),bool); ri=np.arange(wn-1)[:,None]+0.5; li=0.5*(l[:-1]+l[1:])[None,:]
        for (r0,l0,ar,al) in holes: keepq&=~(((ri-r0)/ar)**2+((li-l0)/al)**2<1)
        a=(np.arange(wn-1)[:,None]*NLR+np.arange(NLR-1)[None,:])
        f1=np.stack([a,a+1,a+NLR+1],-1);f2=np.stack([a,a+NLR+1,a+NLR],-1)
        F.append(np.concatenate([f1[keepq],f2[keepq]])+n0); V.append(Vh.reshape(-1,3)); n0+=wn*NLR
    return np.concatenate(V).astype(np.float32),np.concatenate(F).astype(np.int32)
