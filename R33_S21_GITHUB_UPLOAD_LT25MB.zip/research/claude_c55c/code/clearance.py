import numpy as np
from scipy.spatial import cKDTree
import knot
_cache={}
def _prep(n=6000,nseg=12):
    key=(n,nseg,knot.wfun(np.array([0.3]))[0])
    if key in _cache: return _cache[key]
    t=np.linspace(0,2*np.pi,n,endpoint=False)
    P,T,U,B=knot.frame(t); w=knot.wfun(t); R=knot.rwall(t); K=knot.keel(t)
    seg=(np.arange(n)*nseg//n); trees=[]; idxs=[]
    for s in range(nseg):
        ii=np.nonzero(seg==s)[0]; trees.append(cKDTree(P[ii])); idxs.append(ii)
    _cache[key]=(t,P,U,B,w,R,K,seg,trees,idxs,n,nseg,T); return _cache[key]
def f_other(Q,tq,roof=False):
    """signed distance-ish of points Q to strands that are NOT the point's own strand neighbourhood (own seg +-1)."""
    t,P,U,B,w,R,K,seg,trees,idxs,n,nseg,T=_prep()
    ts=((tq/(2*np.pi))*nseg).astype(int)%nseg; best=np.full(len(Q),1e9)
    for s in range(nseg):
        dseg=np.minimum((ts-s)%nseg,(s-ts)%nseg); ok=dseg>=2
        if not ok.any(): continue
        d,ii=trees[s].query(Q[ok],k=3); sel=np.nonzero(ok)[0]
        for c in range(3):
            j=idxs[s][ii[:,c]]; rel=Q[sel]-P[j]
            lm=(rel*B[j]).sum(1); nz=(rel*U[j]).sum(1); ln=np.clip(lm/(w[j]/2),-1,1)
            f=np.maximum(np.maximum(np.abs(lm)-w[j]/2,nz-knot.top_profile(ln,R[j])),knot.bot_profile(ln,K[j])-nz)
            along=np.abs((rel*T[j]).sum(1)); f=np.where(along>25.,np.maximum(f,along-25.),f)   # foot point must be interior
            best[sel]=np.minimum(best[sel],f)
    return best
def clearance(nsamp=60000,seed=1):
    t,P,U,B,w,R,K,seg,trees,idxs,n,nseg,T=_prep()
    rng=np.random.default_rng(seed); ti=rng.integers(0,n,nsamp); l=rng.uniform(-1,1,nsamp); top=rng.random(nsamp)<0.5
    nn=np.where(top,knot.top_profile(l,R[ti]),knot.bot_profile(l,K[ti]))
    Q=P[ti]+B[ti]*(l*w[ti]/2)[:,None]+U[ti]*nn[:,None]
    f=f_other(Q.astype(np.float64),t[ti]); return float(f.min()),float(np.percentile(f,0.1))
if __name__=="__main__":
    print(clearance())
