"""C55-C deferred shading on top of raster.py. Not Blender/PBR: software proxy renderer."""
import numpy as np, cv2, time
from scipy.ndimage import map_coordinates
import raster
from lens import Rth

TILT=np.radians(7.0); YAW=np.radians(25.0); LT=np.array([0,0,1650.])
def Rx(a): c,s=np.cos(a),np.sin(a); return np.array([[1,0,0],[0,c,-s],[0,s,c]])
def Rz(a): c,s=np.cos(a),np.sin(a); return np.array([[c,-s,0],[s,c,0],[0,0,1]])
LM=Rz(YAW)@Rx(TILT)                      # local->world rotation
def l2w(p): return p@LM.T+LT
def w2l(p): return (p-LT)@LM
SUN_AZ,SUN_EL=np.radians(232.),np.radians(4.0)
L=np.array([np.cos(SUN_EL)*np.cos(SUN_AZ),np.cos(SUN_EL)*np.sin(SUN_AZ),np.sin(SUN_EL)])
SUN_COL=np.array([1.0,0.56,0.30])*1.7

def sky(d):
    e=np.clip(d[...,2],-1,1)
    zen=np.array([0.006,0.011,0.040]); mid=np.array([0.030,0.052,0.135]); hor=np.array([0.17,0.23,0.37]); low=np.array([0.035,0.050,0.085])
    t=np.clip(e,0,1)
    k1=sstep_(t/0.16)[...,None]; k2=sstep_(np.clip((t-0.05)/0.9,0,1))[...,None]
    up=(hor*(1-k1)+mid*k1)*(1-k2)+zen*k2
    c=np.where(e[...,None]>0,up,low+(hor-low)*np.exp(e/0.06)[...,None]*0.5)
    ca=np.clip(np.einsum('...i,i->...',d,L),-1,1); ang=np.arccos(ca)
    warm=(np.exp(-(ang/0.9)**2)*0.030+np.exp(-(ang/0.22)**2)*0.10+np.exp(-(ang/0.018)**2)*3.0)[...,None]*SUN_COL
    c=c+warm*(np.exp(-np.maximum(e,0)/0.20)*(e>-0.15))[...,None]
    return c.astype(np.float32)
def sstep_(x):
    x=np.clip(x,0,1); return x*x*(3-2*x)

def hash3(a,b,c):
    h=np.sin(a*127.1+b*311.7+c*74.7)*43758.5453
    return h-np.floor(h)

class Scene:
    def __init__(s,path):
        z=np.load(path); s.V=z['V'];s.F=z['F'];s.N=z['N'];s.COL=z['COL'];s.AUX=z['AUX'];s.MAT=z['MAT'];s.FLAT=z['FLAT']
        v0,v1,v2=s.V[s.F[:,0]],s.V[s.F[:,1]],s.V[s.F[:,2]]
        fn=np.cross(v1-v0,v2-v0); fn/=np.maximum(np.linalg.norm(fn,axis=1,keepdims=True),1e-9); s.FN=fn.astype(np.float32)
class LensField:
    def __init__(s,path='knot_field.npz'):
        z=np.load(path); s.vol=z['vol'].astype(np.float32); s.org=z['org'];s.vox=float(z['vox'])
    def sample(s,pw):
        c=((pw-s.org)/s.vox).T
        return map_coordinates(s.vol,c,order=1,mode='nearest')

def tonemap(x,exposure=1.0):
    x=x*exposure; a,b,c,d,e=2.51,0.03,2.43,0.59,0.14
    y=np.clip((x*(a*x+b))/(x*(c*x+d)+e),0,1); return y**(1/2.2)

def shade(cam,S,LF,zb,idb,bb,opts):
    H,W=zb.shape; img=np.zeros((H,W,3),np.float32)
    ys,xs=np.mgrid[0:H,0:W]
    dirs=(cam.f[None,None,:]+((xs+0.5-W/2)/cam.fpx)[...,None]*cam.r[None,None,:]-((ys+0.5-H/2)/cam.fpx)[...,None]*cam.u[None,None,:]).astype(np.float32)
    dn=dirs/np.linalg.norm(dirs,axis=2,keepdims=True)
    img[:]=sky(dn)
    valid=np.nonzero(idb.ravel()>=0)[0]
    CH=500000
    for a in range(0,len(valid),CH):
        px=valid[a:a+CH]; t=idb.ravel()[px]; z=zb.ravel()[px].astype(np.float64)
        d=dirs.reshape(-1,3)[px].astype(np.float64); dd=d/np.linalg.norm(d,axis=1,keepdims=True)
        P=cam.pos+d*z[:,None]; dist=z*np.linalg.norm(d,axis=1)
        b0=bb.reshape(-1,2)[px,0:1];b1=bb.reshape(-1,2)[px,1:2];b2=1-b0-b1
        f=S.F[t]
        N=b0*S.N[f[:,0]]+b1*S.N[f[:,1]]+b2*S.N[f[:,2]]
        flat=S.FLAT[t]; N=np.where(flat[:,None],S.FN[t],N); N/=np.maximum(np.linalg.norm(N,axis=1,keepdims=True),1e-9)
        sg=np.where((N*dd).sum(1)>0,-1.0,1.0); N=N*sg[:,None]
        alb=b0*S.COL[f[:,0]]+b1*S.COL[f[:,1]]+b2*S.COL[f[:,2]]
        aux=b0*S.AUX[f[:,0]]+b1*S.AUX[f[:,1]]+b2*S.AUX[f[:,2]]
        mat=S.MAT[t]
        # --- lens-field shadow + AO
        sh=np.ones(len(px)); ao=np.ones(len(px))
        # shadow: march toward sun
        if opts.get('shadow',True):
            occ=np.ones(len(px)); ts=[40,120,260,500,850,1300,1900,2700,3800]
            for tt in ts:
                q=P+N*6+L*tt; fv=LF.sample(q); occ=np.minimum(occ,np.clip(fv/(0.12*tt+25),0,1))
            sh=occ
            # ao samples along normal
            aos=0
            for dd_ in (25,70,150,300):
                q=P+N*dd_; fv=LF.sample(q); aos+=np.clip((dd_-np.maximum(fv,0))/dd_,0,1)*(0.30 if dd_<200 else 0.22)
            ao=np.clip(1-aos,0.15,1)
        ndl=np.clip((N*L).sum(1),0,1)*sh
        hemi=0.5+0.5*N[:,2]
        amb=(np.array([0.055,0.075,0.17])*hemi[:,None]+np.array([0.10,0.065,0.06])*(1-hemi)[:,None])*ao[:,None]*opts.get('amb',1.0)
        bounce=(1-ao)[:,None]*np.array([0.34,0.17,0.08])*opts.get('bounce',1.0)
        col=np.zeros((len(px),3)); emis=np.zeros((len(px),3))
        hullm=(mat==0)|(mat==5)
        if hullm.any():
            h=hullm
            diff=alb[h]*(SUN_COL*ndl[h,None]+amb[h]*3.0+bounce[h]*2.0)
            V=-dd[h]; ndv=np.clip((N[h]*V).sum(1),0,1); Fr=0.045+0.955*(1-ndv)**5
            R=-V+2*ndv[:,None]*N[h]; rs=sky(R/np.linalg.norm(R,axis=1,keepdims=True)).astype(np.float64)
            spec=rs*(Fr*ao[h])[:,None]*0.85
            gl=np.clip((R*L).sum(1),0,1)**48*sh[h]; spec+=SUN_COL*(gl*0.5)[:,None]*(0.25+Fr)[:,None]
            col[h]=diff+spec
        gm=(mat==6)
        if gm.any():
            g=gm; ft=f[g]; Pg=P[g]; Ng=N[g]
            diff=alb[g]*(SUN_COL*ndl[g,None]+amb[g]*3.0+bounce[g]*2.2)
            steep=aux[g,0]
            # in-plane direction of increasing arclength (=ribbon tangent) from per-triangle vertex data
            s0,s1,s2=S.AUX[ft[:,0],1],S.AUX[ft[:,1],1],S.AUX[ft[:,2],1]
            e1=S.V[ft[:,1]]-S.V[ft[:,0]]; e2=S.V[ft[:,2]]-S.V[ft[:,0]]
            aa=(e1*e1).sum(1);bb_=(e1*e2).sum(1);cc=(e2*e2).sum(1);det=aa*cc-bb_*bb_+1e-6
            ds1=s1-s0; ds2=s2-s0
            gv=((ds1*cc-ds2*bb_)[:,None]*e1+(ds2*aa-ds1*bb_)[:,None]*e2)/det[:,None]
            gn=gv/np.maximum(np.linalg.norm(gv,axis=1,keepdims=True),1e-9)
            Ud=np.cross(Ng,gn); Ud/=np.maximum(np.linalg.norm(Ud,axis=1,keepdims=True),1e-9)
            u=aux[g,1]; v=(Pg*Ud).sum(1)
            cw,ch=15.0,10.0; cu=np.floor(u/cw); cv=np.floor(v/ch)
            sd=hash3(np.floor(u/180),np.floor(v/53),3.0)
            on=hash3(cu,cv,sd*50)<(0.45+0.4*sd)
            fu=u/cw-cu; fv=v/ch-cv; inwin=(fu>0.14)&(fu<0.86)&(fv>0.18)&(fv<0.82)
            fpx=dist[g]/cam.fpx; blend=np.clip((fpx-ch*0.25)/(ch*0.75),0,1)
            mean=(0.45+0.4*sd)*0.62*0.64*0.55
            hh=hash3(cu,cv,7.0)
            wc=np.where((hh<0.14)[:,None],np.array([0.60,0.85,1.0]),np.where((hh>0.82)[:,None],np.array([0.95,0.90,0.85]),np.array([1.0,0.64,0.34])*(0.75+0.5*hh)[:,None]))
            wint=np.where(on&inwin,1.0,0.0)*(1-blend)+mean*blend
            rw=np.clip((steep-0.35)/0.35,0,1)
            e=wc*(wint*1.15*rw)[:,None]+np.array([1.0,0.6,0.28])*((1-rw)*0.012)[:,None]
            col[g]=diff; emis[g]=e
        # ---- ground
        g=mat==1
        if g.any():
            diff=alb[g]*(SUN_COL*ndl[g,None]*0.9+amb[g]*3.0+bounce[g])
            col[g]=diff
            # district glow from city lights (noise field)
            glow=np.clip(aux[g,0],0,1)**1.4
            emis[g]=np.array([1.0,0.58,0.26])*(glow*0.22)[:,None]
        # ---- buildings / slabs
        bm=(mat==2)|(mat==3)
        if bm.any():
            b=bm; diff=alb[b]*(SUN_COL*ndl[b,None]+amb[b]*3.0+bounce[b]*2.5)
            col[b]=diff
            Pb=P[b];Nb=N[b];seed=np.round(aux[b,0],3);dens=aux[b,1]
            vert=np.abs(Nb[:,2])<0.45
            tu=np.stack([-Nb[:,1],Nb[:,0]],1); u=Pb[:,0]*tu[:,0]+Pb[:,1]*tu[:,1]; v=Pb[:,2]
            cw,ch=11.0,8.5; cu=np.floor(u/cw);cv=np.floor(v/ch)
            on=hash3(cu,cv,seed*91.7)<dens
            fu=u/cw-cu; fv=v/ch-cv; inwin=(fu>0.16)&(fu<0.84)&(fv>0.20)&(fv<0.80)
            fp=dist[b]/cam.fpx; blend=np.clip((fp-ch*0.25)/(ch*0.75),0,1)
            mean=dens*0.62*0.60*0.14
            m3=(mat[b]==3)
            hh=hash3(cu,cv,seed*13.1)
            wc=np.where((hh<0.16)[:,None],np.array([0.60,0.85,1.0]),np.where((hh>0.80)[:,None],np.array([0.95,0.92,0.88]),np.array([1.0,0.68,0.38])*(0.75+0.5*hh)[:,None]))
            wint=np.where(on&inwin,1.0,0.0)*(1-blend)+mean*blend
            e=wc*(wint*1.35*vert)[:,None]
            # slab light strip: whole vertical face glows amber
            e=np.where(m3[:,None],np.array([1.0,0.62,0.30])*(vert*1.3*(0.5+0.5*dens))[:,None]+0.0,e)
            emis[b]=e
        # ---- pure emissive (canal / light ribbons)
        em4=mat==4
        if em4.any():
            col[em4]=0; emis[em4]=alb[em4]*opts.get('canal',1.5)
        # fog
        zc=cam.pos[2]; havg=np.maximum((zc+P[:,2])*0.5,0)
        dens_f=opts.get('fog',1/26000.)*np.exp(-havg/3500.)
        T=np.exp(-dist*dens_f)
        fogc=sky(np.stack([dd[:,0],dd[:,1],np.clip(dd[:,2],0,0.02)*0+0.015],1)/np.linalg.norm(np.stack([dd[:,0],dd[:,1],dd[:,2]*0+0.015],1),axis=1,keepdims=True))*0.9
        total=(col+emis)
        img.reshape(-1,3)[px]=total*T[:,None]+fogc*(1-T)[:,None]
    # ---- volumetric light shaft + core haze
    if opts.get("shaft",False): img+=shaft(cam,dirs,zb,**opts.get('shaft_kw',{}))
    return img
def shaft(cam,dirs,zb,ax=(0.,0.),zbot=-80.,ztop=7000.,sig0=38.,amt=0.0016):
    H,W=zb.shape; ax=np.array(ax)
    d=dirs.reshape(-1,3).astype(np.float64); o=cam.pos
    dx,dy=d[:,0],d[:,1]; ox,oy=o[0]-ax[0],o[1]-ax[1]
    a=dx*dx+dy*dy+1e-12; tc=-(ox*dx+oy*dy)/a; tc=np.maximum(tc,0)
    cx=ox+dx*tc; cy=oy+dy*tc; dmin=np.hypot(cx,cy)
    m=dmin<500; out=np.zeros((H*W,3),np.float32)
    if not m.any(): return out.reshape(H,W,3)
    idx=np.nonzero(m)[0]; dd=d[idx]; zz=np.where(np.isfinite(zb.ravel()[idx]),zb.ravel()[idx],1e9)
    acc=np.zeros(len(idx)); a2=a[idx]; tc2=tc[idx]; half=np.sqrt(np.maximum(3*500.**2-(dmin[idx]**2),1))/np.sqrt(a2)
    for s_ in np.linspace(-1,1,48):
        t=np.maximum(tc2+s_*half,0.0); p=o+dd*t[:,None]; r=np.hypot(p[:,0]-ax[0],p[:,1]-ax[1]); zp=p[:,2]
        inz=(zp>zbot)&(zp<ztop)&(t<zz); sig=sig0+0.004*np.clip(zp,0,None)
        dens=np.exp(-(r/sig)**2)+0.25*np.exp(-(r/(sig*4))**2)
        acc+=dens*inz*(np.sqrt(a2)*half*2/48)
    out[idx]=(np.array([0.50,0.82,1.0])*(acc*amt)[:,None]).astype(np.float32)
    return out.reshape(H,W,3)

def render(cam,S,LF,ss=2,opts=None,log=print):
    opts=opts or {}
    cs=raster.Camera(cam.pos,cam.pos+cam.f,cam.fov,cam.W*ss,cam.H*ss)
    cs.r,cs.u,cs.f=cam.r,cam.u,cam.f
    t=time.time(); zb,idb,bb=raster.rasterize(cs,S.V,S.F,log=log); log(f"  raster {time.time()-t:.1f}s")
    t=time.time(); img=shade(cs,S,LF,zb,idb,bb,opts); log(f"  shade {time.time()-t:.1f}s")
    img=cv2.resize(img,(cam.W,cam.H),interpolation=cv2.INTER_AREA) if ss>1 else img
    # bloom
    lum=img.max(2,keepdims=True); bright=np.clip(img-1.2,0,None)*(lum>1.2)
    bl=cv2.GaussianBlur(bright,(0,0),cam.W/180)*0.9+cv2.GaussianBlur(bright,(0,0),cam.W/45)*0.7
    out=img+bl
    yy,xx=np.mgrid[0:cam.H,0:cam.W]; vg=1-0.28*(((xx-cam.W/2)/(cam.W/2))**2+((yy-cam.H/2)/(cam.H/2))**2)
    out=tonemap(out*vg[...,None]*opts.get('exposure',1.0))
    return (np.clip(out,0,1)*255).astype(np.uint8)[:,:,::-1]
