import numpy as np
CUBE_V=np.array([[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1],[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]],np.float32)
CUBE_F=np.array([[0,2,1],[0,3,2],[4,5,6],[4,6,7],[0,1,5],[0,5,4],[1,2,6],[1,6,5],[2,3,7],[2,7,6],[3,0,4],[3,4,7]],np.int32)
class Parts:
    def __init__(s): s.V=[];s.F=[];s.N=[];s.C=[];s.A=[];s.M=[];s.FL=[];s.n=0;s.names=[];s.ranges={}
    def add(s,name,V,F,N,C,A,mat,flat):
        V=np.asarray(V,np.float32);F=np.asarray(F,np.int32)
        if N is None: N=np.zeros_like(V)
        C=np.broadcast_to(np.asarray(C,np.float32),V.shape).copy()
        A=np.broadcast_to(np.asarray(A,np.float32),(len(V),2)).copy()
        mat=np.broadcast_to(np.asarray(mat,np.int8),(len(F),)).copy()
        s.ranges[name]=(len(s.F and np.concatenate(s.F) or []) if False else sum(len(f) for f in s.F),len(F))
        s.V.append(V);s.F.append(F+s.n);s.N.append(np.asarray(N,np.float32));s.C.append(C);s.A.append(A);s.M.append(mat)
        s.FL.append(np.full(len(F),flat,bool)); s.n+=len(V); s.names.append(name)
    def pack(s):
        return dict(V=np.concatenate(s.V),F=np.concatenate(s.F),N=np.concatenate(s.N),COL=np.concatenate(s.C),AUX=np.concatenate(s.A),MAT=np.concatenate(s.M),FLAT=np.concatenate(s.FL))
def boxes(centers,axes,half,colors,seeds,dens,pitch=None):
    """centers (n,3); axes (n,3,3) rows ex,ey,ez unit; half (n,3). returns V,F,C,A"""
    n=len(centers)
    loc=CUBE_V[None]*half[:,None,:]                        # n,8,3
    V=centers[:,None,:]+np.einsum('nvk,nkj->nvj',loc,axes)
    F=(CUBE_F[None]+(np.arange(n)*8)[:,None,None]).reshape(-1,3)
    C=np.repeat(colors,8,axis=0)
    A=np.stack([np.repeat(seeds,8),np.repeat(dens,8)],1)
    return V.reshape(-1,3).astype(np.float32),F.astype(np.int32),C.astype(np.float32),A.astype(np.float32)
def yaw_axes(yaw):
    c,s=np.cos(yaw),np.sin(yaw); n=len(yaw); a=np.zeros((n,3,3),np.float32)
    a[:,0,0]=c;a[:,0,1]=s;a[:,1,0]=-s;a[:,1,1]=c;a[:,2,2]=1; return a
def vnormals(V,F):
    fn=np.cross(V[F[:,1]]-V[F[:,0]],V[F[:,2]]-V[F[:,0]]); N=np.zeros_like(V)
    for k in range(3): np.add.at(N,F[:,k],fn)
    return (N/np.maximum(np.linalg.norm(N,axis=1,keepdims=True),1e-9)).astype(np.float32)
def sstep(a,b,x):
    t=np.clip((x-a)/(b-a),0,1); return t*t*(3-2*t)
