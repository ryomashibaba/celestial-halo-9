import numpy as np
from geo import *
import knot
def make_open(P,Uref,w,R,K,nl=61):
    n=len(P); T=np.gradient(P,axis=0); T/=np.linalg.norm(T,axis=1,keepdims=True)
    U=Uref-(Uref*T).sum(1,keepdims=True)*T; U/=np.linalg.norm(U,axis=1,keepdims=True); B=np.cross(U,T)
    l=np.linspace(-1,1,nl)
    topn=knot.top_profile(l[None,:],R[:,None]); botn=knot.bot_profile(l[None,:],K[:,None])
    topn[:,0]=topn[:,-1]=R*1.0; botn[:,0]=botn[:,-1]=-22.*np.clip(w/200,0.05,1)[:]
    lat=l[None,:]*w[:,None]/2
    Vt=P[:,None,:]+B[:,None,:]*lat[...,None]+U[:,None,:]*topn[...,None]
    Vb=P[:,None,:]+B[:,None,:]*lat[...,None]+U[:,None,:]*botn[...,None]
    V=np.concatenate([Vt,Vb],1).reshape(-1,3).astype(np.float32); K2=2*nl
    dl=np.gradient(lat,axis=1); slope=np.abs(np.gradient(topn,axis=1)/np.maximum(np.abs(dl),1e-3)); steep=np.clip(slope/0.9,0,1)
    arcs=np.concatenate([[0],np.cumsum(np.linalg.norm(np.diff(P,axis=0),axis=1))])
    A=np.zeros((n,K2,2),np.float32); A[:,:nl,0]=steep; A[:,:,1]=arcs[:,None]
    idx=lambda i,j:i*K2+j
    ii=np.arange(n-1)[:,None]; jj=np.arange(nl-1)[None,:]; F=[];M=[]
    for off,mat in ((0,6),(nl,0)):
        a=idx(ii,off+jj);b=idx(ii,off+jj+1);c=idx(ii+1,off+jj);d=idx(ii+1,off+jj+1)
        f1=np.stack([a,b,d],-1).reshape(-1,3);f2=np.stack([a,d,c],-1).reshape(-1,3); F+=[f1,f2];M+=[np.full(len(f1),mat),np.full(len(f2),mat)]
    for e in (0,nl-1):
        i=np.arange(n-1); a=idx(i,e);b=idx(i,nl+e);c=idx(i+1,e);d=idx(i+1,nl+e)
        F+=[np.stack([a,b,d],1),np.stack([a,d,c],1)];M+=[np.zeros(n-1),np.zeros(n-1)]
    F=np.concatenate(F).astype(np.int32);M=np.concatenate(M).astype(np.int8)
    N=vnormals(V,F); C=np.zeros((len(V),3),np.float32)
    C.reshape(n,K2,3)[:,:nl]=np.array([0.034,0.032,0.036]);C.reshape(n,K2,3)[:,nl:]=np.array([0.016,0.018,0.027])
    return V,F,M,N,C,A.reshape(-1,2),dict(P=P,T=T,U=U,B=B,w=w,R=R,arcs=arcs)
def city_open(fr,rng,spacing=34.):
    P,T,U,B,w,R,arcs=[fr[k] for k in ('P','T','U','B','w','R','arcs')]
    L=arcs[-1]; ns=int(L/spacing); sg=np.linspace(0.02*L,0.98*L,ns)
    I=lambda X:np.stack([np.interp(sg,arcs,X[:,k]) for k in range(3)],1)
    Pi,Ti,Ui,Bi=I(P),I(T),I(U),I(B)
    for X in (Ti,Ui,Bi): X/=np.linalg.norm(X,axis=1,keepdims=True)
    wi=np.interp(sg,arcs,w);Ri=np.interp(sg,arcs,R)
    cent=[];axs=[];hf=[];col=[];seed=[];dens=[]
    tread_c=[knot.S0+(1-knot.S0)*(k+0.55)/knot.NSTEP for k in range(knot.NSTEP)]
    cols=[(-1,0.18,0),(1,0.18,0)]+[(s_,c,k+1) for k,c in enumerate(tread_c) for s_ in (-1,1)]
    for (sgn,lf,k) in cols:
        for i in range(ns):
            if wi[i]<260 or rng.random()>(0.75 if k==0 else 0.55): continue
            lm=sgn*lf*wi[i]/2; ln=lm/(wi[i]/2); topn=knot.top_profile(np.array([abs(ln)]),np.array([Ri[i]]))[0]
            if k==0: lenT=rng.uniform(16,44);wid=rng.uniform(22,56);hg=min(np.exp(rng.normal(np.log(50),0.5)),Ri[i]*0.5)
            else: lenT=rng.uniform(14,34);wid=rng.uniform(14,28);hg=min(np.exp(rng.normal(np.log(24),0.5)),70,Ri[i]-topn+8)
            c=Pi[i]+Bi[i]*lm+Ui[i]*(topn+hg/2-2); cent.append(c);axs.append(np.stack([Ti[i],Bi[i],Ui[i]]));hf.append([lenT/2,wid/2,hg/2])
            g=rng.uniform(0.10,0.17);col.append([g,g*0.97,g*0.95]);seed.append(rng.random());dens.append(rng.uniform(0.3,0.8))
    if not cent: return None
    return boxes(np.array(cent,np.float32),np.array(axs,np.float32),np.array(hf,np.float32),np.array(col,np.float32),np.array(seed,np.float32),np.array(dens,np.float32))
def satellites(rng):
    out=[]; specs=[]
    for k in range(6):
        ang=0.35+k*2.05; rc=6500+k*520; zc=1500+520*np.sin(k*1.3+0.4)+k*150
        Rarc=760+110*((k*7)%5); span=np.radians(150+14*((k*5)%6)); a0=rng.uniform(0,2*np.pi)
        n=int(Rarc*span/24)
        s=np.linspace(0,1,n); a=a0+span*s
        e1=np.array([np.cos(ang+0.9),np.sin(ang+0.9),0]); e2=np.array([-np.sin(ang+0.9),np.cos(ang+0.9),0])
        ctr=np.array([rc*np.cos(ang),rc*np.sin(ang),zc])
        wob=170*np.sin(2*np.pi*s*1.4+k)
        tilt=np.radians(14+8*k%3)
        P=ctr+Rarc*(np.cos(a)[:,None]*e1+np.sin(a)[:,None]*e2)+np.array([0,0,1])*(wob+Rarc*0.35*np.sin(a-a0)*np.sin(tilt))[:,None]
        rad=(P-ctr)*np.array([1,1,0]); rad/=np.linalg.norm(rad,axis=1,keepdims=True)
        Uref=rad*np.cos(np.radians(40))+np.array([0,0,1])*np.sin(np.radians(40))
        env=np.sin(np.pi*s)**0.55
        w=(430+90*(k%3))*np.maximum(env,0.04); R_=(300+30*(k%2))*np.maximum(env,0.05); K_=(210)*np.maximum(env,0.05)
        out.append(make_open(P,Uref,w,R_,K_)); specs.append((k,float(rc),float(zc),float(Rarc)))
    return out,specs
