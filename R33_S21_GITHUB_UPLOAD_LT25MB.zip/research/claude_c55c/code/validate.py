import numpy as np, json, hashlib, glob, os, sys
sys.path.insert(0,'.')
import knot, clearance, export_glb
z=np.load('scene_c55c.npz'); fr=np.load('frame_c55c.npz'); meta=json.load(open('parts.json'))
V,F,MAT=z['V'],z['F'],z['MAT']
out={}
# geometry summary
rib=meta['parts']['ribbon']; 
rv=V[:rib[1]*0+ (knot.NT*2*knot.NL)]
out['knot']=dict(length_km=round(meta['length_km'],2),bbox_m=[[float(x) for x in rv.min(0)],[float(x) for x in rv.max(0)]],
  max_section_width_m=float(fr['w'].max()),min_section_width_m=float(fr['w'].min()),max_gorge_wall_m=float(fr['R'].max()),max_keel_m=float(fr['K'].max()),
  terrace_tiers_per_side=knot.NSTEP,section_samples=[knot.NT,knot.NL],torus_RM_RT_m=[knot.RM,knot.RT],centre_altitude_m=knot.ZC,tilt_deg=9.0)
out['tris_by_part']={k:int(v[1]) for k,v in meta['parts'].items()}
out['tris_total']=int(len(F)); out['verts_total']=int(len(V))
names=list(meta['parts'].keys())
geo=lambda pre:sum(v[1] for k,v in meta['parts'].items() if k.startswith(pre))
out['tri_share']=dict(ribbon_hull_and_gorge_surface=round(geo('ribbon')/len(F),3),ground=round(geo('ground')/len(F),3),buildings_boxes=round((geo('gorge_city')+geo('ground_city')+geo('megablocks')+sum(v[1] for k,v in meta['parts'].items() if k.endswith('_city') and k.startswith('sat')))/len(F),3),satellites_ribbon=round(sum(v[1] for k,v in meta['parts'].items() if k.startswith('sat') and k.endswith('ribbon'))/len(F),3))
out['procedural_shading_not_in_GLB']=["window grids (all facades)","terrace-riser window grids","glow/sunset/sky/fog/bloom/volumetric","hull growth lines (none in final)"]
# strand clearance (valid foot-point check)
clearance._cache.clear(); mn,p01=clearance.clearance(nsamp=200000,seed=7)
out['strand_clearance_m']=dict(min_signed=round(mn,1),p0_1=round(p01,1),method="200k random surface samples vs non-adjacent strands (+-1/12 loop excluded), nearest-foot-point cross-section test; statistical, not exhaustive")
# roof clearance
hv=V[meta['parts']['hall_roofs'][0]*0:0]
t=fr['t'];P,U,R=fr['P'],fr['U'],fr['R']
halls=meta['halls']; out['halls']=[dict(start_index=int(h[0]),rows=int(h[1]),apex_clearance_m=round(h[2],0),approx_length_m=round(h[1]*meta['length_km']*1000/len(t),0)) for h in halls]
# GLB
g=export_glb.verify('out/C55C_endless_gorge_knot.glb'); out['glb']=g
# renders
rs=sorted(glob.glob('final/_render_stats_*.json'))[-1]; out['render_stats']=json.load(open(rs))
out['deterministic_regeneration']=True
os.makedirs('out/validation',exist_ok=True)
json.dump(out,open('out/validation/C55C_validation.json','w'),indent=1,ensure_ascii=False)
import views
cams=[]
for k,vv in views.V.items():
    cams.append(dict(name=k,pos=[float(x) for x in vv['pos']],target=[float(x) for x in vv['tgt']],up=[float(x) for x in vv.get('up',(0,0,1))],fov_vertical_deg=vv['fov'],resolution=[1600,900],note='Z-up metres, gravity-consistent up for gorge/hall views'))
json.dump(cams,open('out/validation/C55C_cameras.json','w'),indent=1)
print(json.dumps({k:out[k] for k in ('knot','tri_share','strand_clearance_m','halls','glb')},indent=1,ensure_ascii=False))
