# UNTESTED (Blender was not available when this was written).
# Intended: import the GLB, make the 12 review cameras (with gravity-consistent up vectors), boost the emissive material.
# Run:  blender -P blender_import_UNTESTED.py   then File > Save As .blend  (this is how the first .blend should be produced)
import bpy, json, math, mathutils, os
base = os.path.dirname(os.path.abspath(__file__))
bpy.ops.import_scene.gltf(filepath=os.path.join(base, '..', 'model', 'C55C_endless_gorge_knot.glb'))   # glTF Y-up -> Blender Z-up, same world coords as the generator
for m in bpy.data.materials:
    if m.name.startswith('C55C_emissive'):
        n = m.node_tree.nodes.get('Principled BSDF')
        if n:
            n.inputs['Emission Strength'].default_value = 8.0
cams = json.load(open(os.path.join(base, '..', 'validation', 'C55C_cameras.json')))
for c in cams:
    cd = bpy.data.cameras.new(c['name']); cd.sensor_fit = 'VERTICAL'; cd.angle_y = math.radians(c['fov_vertical_deg']); cd.clip_end = 90000
    ob = bpy.data.objects.new(c['name'], cd); bpy.context.collection.objects.link(ob)
    pos = mathutils.Vector(c['pos']); fwd = (mathutils.Vector(c['target']) - pos).normalized(); up = mathutils.Vector(c['up'])
    z = -fwd; x = up.cross(z).normalized(); y = z.cross(x)          # camera looks along -Z, up = +Y
    ob.matrix_world = mathutils.Matrix([[x[0], y[0], z[0], pos[0]], [x[1], y[1], z[1], pos[1]], [x[2], y[2], z[2], pos[2]], [0, 0, 0, 1]])
# NOTE: window grids, riser windows, sky, fog, bloom and sunset lighting of the review renders are PROCEDURAL SHADING in render.py and are NOT in the GLB.
