import numpy as np, time, json
from geo import *
import knot, field
rng=np.random.default_rng(55)
def gz(x,y):
    r=np.hypot(x,y); return -85*np.exp(-(r/620.)**2)-8*np.exp(-(r/2400.)**2)
CG=0.50; R0G=420.
def arm_info(x,y,narm=3):
    r=np.maximum(np.hypot(x,y),1.0); th=np.arctan2(y,x); lr=np.log(r/R0G)
    best=np.full(r.shape,9.0)
    for k in range(narm):
        # arm: theta = -lr/CG + 2pi k/narm ; find nearest in angle (wrapped)
        dth=(th-(-lr/CG+2*np.pi*k/narm)+np.pi)%(2*np.pi)-np.pi
        best=np.minimum(best,np.abs(dth)*r/260.)   # lateral distance / 260m
    return best
t0=time.time(); parts=Parts()
# ---- ribbon
V,F,M,N,C,A,fr=knot.build_ribbon()
parts.add('ribbon',V,F,N,C,A,M,False); print("ribbon",len(F))
# ---- gorge city
(bv,bf,bc,ba),nb,lv=knot.cityscape(fr,rng); parts.add('gorge_city',bv,bf,None,bc,ba,2,True); print("gorge boxes",nb)
cv,cf=knot.canal(fr); parts.add('gorge_canal',cv,cf,None,[0.25,0.95,1.0],0,4,True)
fv,ff,bot=knot.keel_fins(fr,rng); parts.add('keel_fins',fv,ff,None,[0.02,0.022,0.03],0,0,True)
# glowing fin edge
n=len(bot); i=np.arange(n); j=(i+1)%n; U=fr['U']
b2=bot-U*7.0; ev=np.stack([bot,b2],1).reshape(-1,3); ef=np.concatenate([np.stack([2*i,2*i+1,2*j+1],1),np.stack([2*i,2*j+1,2*j],1)])
parts.add('fin_edge',ev,ef,None,[0.75,0.9,1.0],0,4,True)
# ---- ground
nr=[];r=0.
rs=[0.]
while rs[-1]<70000: rs.append(rs[-1]+max(18.,0.022*rs[-1]))
rs=np.array(rs); NA=512; th=np.linspace(0,2*np.pi,NA,endpoint=False)
RR,TH=np.meshgrid(rs,th,indexing='ij'); X=RR*np.cos(TH);Y=RR*np.sin(TH);Z=gz(X,Y)
Vg=np.stack([X,Y,Z],-1).reshape(-1,3).astype(np.float32)
arm=arm_info(X.ravel(),Y.ravel()); gw=np.exp(-arm**2*1.4)*np.exp(-(RR.ravel()/3600)**2)
br=0.022*(1+0.8*gw)
colg=np.stack([br*0.85,br*1.0,br*1.3],1).astype(np.float32)
Ag=np.stack([gw,np.zeros_like(gw)],1).astype(np.float32)
ii=np.arange(len(rs)-1)[:,None];jj=np.arange(NA)[None,:]
a=ii*NA+jj;b=ii*NA+(jj+1)%NA;c=(ii+1)*NA+jj;d=(ii+1)*NA+(jj+1)%NA
Fg=np.concatenate([np.stack([a,b,d],-1).reshape(-1,3),np.stack([a,d,c],-1).reshape(-1,3)]).astype(np.int32)
Ng=np.tile([0,0,1.],(len(Vg),1)).astype(np.float32)
parts.add('ground',Vg,Fg,Ng,colg,Ag,1,False); print("ground tris",len(Fg))
# ---- ground canals along arms
for k in range(3):
    thk=np.linspace(0,-np.log(5600/R0G)/CG*-1,1)  # placeholder
    s=np.linspace(0,np.log(5600/R0G)/CG,1400); rr=R0G*np.exp(CG*s); tt=-s+2*np.pi*k/3
    px=rr*np.cos(tt);py=rr*np.sin(tt)
    tx=np.gradient(px);ty=np.gradient(py);nn=np.hypot(tx,ty);nx,ny=-ty/nn,tx/nn
    wd=9+rr*0.0012
    v1=np.stack([px+nx*wd,py+ny*wd,gz(px,py)+1.2],1);v2=np.stack([px-nx*wd,py-ny*wd,gz(px,py)+1.2],1)
    Vc=np.stack([v1,v2],1).reshape(-1,3);q=np.arange(len(s)-1)
    Fc=np.concatenate([np.stack([2*q,2*q+1,2*q+3],1),np.stack([2*q,2*q+3,2*q+2],1)])
    parts.add(f'ground_canal{k}',Vc,Fc,None,[0.20,0.85,0.95],0,4,True)
# ---- ground city (ring placement along spiral arms)
cent=[];hf=[];col=[];seed=[];dens=[];yaw=[]
r=520.
while r<8600:
    n=int(2*np.pi*r/40.); th=np.linspace(0,2*np.pi,n,endpoint=False)+rng.uniform(0,0.2)
    x=r*np.cos(th)+rng.uniform(-5,5,n);y=r*np.sin(th)+rng.uniform(-5,5,n)
    am=arm_info(x,y); p=(0.12+0.85*np.exp(-am**2*1.1))*np.clip(1.25-r/7600,0.06,1)
    keep=rng.random(n)<p
    for xi,yi,ai in zip(x[keep],y[keep],am[keep]):
        rr=np.hypot(xi,yi); wide=rng.uniform(16,34); lng=rng.uniform(18,40)
        h=np.exp(rng.normal(np.log(26*(1+3.4*np.exp(-rr/1500))),0.55)); h=min(h,260)
        cent.append([xi,yi,gz(xi,yi)+h/2-1]);hf.append([lng/2,wide/2,h/2])
        g=rng.uniform(0.030,0.070);col.append([g*0.95,g*1.0,g*1.15]);seed.append(rng.random());dens.append(rng.uniform(0.25,0.85)*(0.55+0.45*np.exp(-rr/3000)))
        # yaw along spiral tangent: angle = polar + atan2(1,-CG)
        yaw.append(np.arctan2(yi,xi)+np.arctan2(1.0,-CG))
    r+=42.
cent=np.array(cent,np.float32);hf=np.array(hf,np.float32);yaw=np.array(yaw)
gv,gf,gc,ga=boxes(cent,yaw_axes(yaw),hf,np.array(col,np.float32),np.array(seed,np.float32),np.array(dens,np.float32))
parts.add('ground_city',gv,gf,None,gc,ga,2,True); print("ground boxes",len(cent))
# interior halls (roofed gorge sections)
halls=knot.pick_halls(fr); print("halls",halls)
hv,hf_=knot.roofs(fr,halls,rng); parts.add('hall_roofs',hv,hf_,vnormals(hv,hf_),[0.022,0.026,0.038],0,0,False); print("roof tris",len(hf_))
# megablocks along arms (mid-ground hierarchy)
mc=[];mh=[];mcol=[];myaw=[]
for k in range(3):
    s=np.arange(0.35,np.log(8200/R0G)/CG,0.11)
    for si in s:
        rr=R0G*np.exp(CG*si); tt=-si+2*np.pi*k/3+rng.normal(0,0.012)
        off=rng.choice([-1,1])*rng.uniform(55,110)
        tx,ty=np.cos(tt)*CG*(-1)*0+(-np.sin(tt)),np.cos(tt)  # tangent approx (circular direction)
        x=rr*np.cos(tt);y=rr*np.sin(tt)
        yaw_=np.arctan2(y,x)+np.arctan2(1.0,-CG)
        L_=rng.uniform(260,820); T_=rng.uniform(34,70); H_=min(np.exp(rng.normal(np.log(150*(1+1.2*np.exp(-rr/2500))),0.45)),420)
        x+=off*np.cos(yaw_+np.pi/2); y+=off*np.sin(yaw_+np.pi/2)
        mc.append([x,y,gz(x,y)+H_/2-1]);mh.append([L_/2,T_/2,H_/2]);myaw.append(yaw_);g=rng.uniform(0.025,0.05);mcol.append([g*0.95,g,g*1.15])
mc=np.array(mc,np.float32);mh=np.array(mh,np.float32)
mv,mf,mcc,ma=boxes(mc,yaw_axes(np.array(myaw)),mh,np.array(mcol,np.float32),rng.random(len(mc)).astype(np.float32),rng.uniform(0.35,0.7,len(mc)).astype(np.float32))
parts.add('megablocks',mv,mf,None,mcc,ma,2,True); print("megablocks",len(mc))
# satellite gorge-ribbons
import sat
sats,specs=sat.satellites(rng)
for k,(Vs,Fs,Ms,Ns,Cs,As,frs) in enumerate(sats):
    parts.add(f'sat{k}_ribbon',Vs,Fs,Ns,Cs,As,Ms,False)
    cb=sat.city_open(frs,rng)
    if cb is not None: parts.add(f'sat{k}_city',cb[0],cb[1],None,cb[2],cb[3],2,True)
print("satellites",specs)
# central light pool
a=np.linspace(0,2*np.pi,96,endpoint=False); pv=np.concatenate([[[0,0,gz(0,0)+1.5]],np.stack([230*np.cos(a),230*np.sin(a),np.full(96,gz(0,0)+1.5)],1)]).astype(np.float32)
pf=np.array([[0,1+i,1+(i+1)%96] for i in range(96)],np.int32); parts.add('light_pool',pv,pf,None,[0.55,0.9,1.0],0,4,True)
rv,rf=knot.ribs(V,N); parts.add('keel_ribs',rv,rf,vnormals(rv,rf),[0.02,0.022,0.03],0,0,False); print("ribs",len(rf))
pk=parts.pack(); np.savez_compressed('scene_c55c.npz',**pk)
print("total V",len(pk['V']),"F",len(pk['F']),"time",time.time()-t0)
json.dump(dict(parts={k:v for k,v in parts.ranges.items()},length_km=fr['length']/1000,halls=[list(map(float,h)) for h in halls]),open('parts.json','w'))
np.savez_compressed('frame_c55c.npz',**{k:fr[k] for k in ('t','P','T','U','B','w','R','K','arcs')})
t=time.time(); field.build_field(fr,halls=halls); print("field",time.time()-t)
