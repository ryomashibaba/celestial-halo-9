import numpy as np
from scipy.spatial import cKDTree
import knot
def build_field(fr,vox=48.,out='knot_field.npz',halls=()):
    t=np.linspace(0,2*np.pi,7000,endpoint=False)
    P,T,U,B=knot.frame(t); w=knot.wfun(t); R=knot.rwall(t); K=knot.keel(t)
    tr=cKDTree(P)
    xs=np.arange(-4400,4400+vox,vox); ys=xs; zs=np.arange(500,5200+vox,vox)
    X,Y,Z=np.meshgrid(xs,ys,zs,indexing='ij'); Q=np.stack([X.ravel(),Y.ravel(),Z.ravel()],1).astype(np.float64)
    d,i=tr.query(Q); rel=Q-P[i]
    lm=(rel*B[i]).sum(1); n=(rel*U[i]).sum(1); ln=np.clip(lm/(w[i]/2),-1,1)
    top=knot.top_profile(ln,R[i]); bot=knot.bot_profile(ln,K[i])
    f=np.maximum(np.maximum(np.abs(lm)-w[i]/2,n-top),bot-n)
    for (i0,wn,_) in halls:
        n6=len(t); j0=int(i0/1500*n6); jw=int(wn/1500*n6); jj=(i[:]-j0)%n6
        inh=jj<jw
        rt=knot.roof_profile(ln,R[i]); fr_=np.maximum(np.maximum(np.abs(lm)-w[i]/2,n-(rt+18)),(rt-n))
        f=np.where(inh,np.minimum(f,fr_),f)
    f=np.where(d>1500,d-1500+50,f)
    vol=f.reshape(X.shape).astype(np.float32)
    np.savez_compressed(out,vol=vol.astype(np.float16),org=np.array([xs[0],ys[0],zs[0]]),vox=vox)
    return vol
