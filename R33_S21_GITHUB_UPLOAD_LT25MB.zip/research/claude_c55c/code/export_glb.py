"""Pure-numpy GLB writer for C55-C. One primitive per material group; indexed; boxes without normals (flat)."""
import numpy as np, json, struct, hashlib, sys
MATS={0:("C55C_hull_obsidian",[0.02,0.022,0.03,1],0.0,0.25,[0,0,0]),
      1:("C55C_ground",[0.03,0.03,0.04,1],0.0,0.9,[0,0,0]),
      2:("C55C_building_facade",[0.1,0.1,0.11,1],0.0,0.6,[0.12,0.07,0.03]),
      4:("C55C_emissive_light",[0,0,0,1],0.0,0.5,[0.25,0.95,1.0]),
      6:("C55C_gorge_terrace_surface",[0.034,0.032,0.036,1],0.0,0.7,[0.12,0.07,0.03])}
def to_yup(V): return np.stack([V[:,0],V[:,2],-V[:,1]],1)   # Z-up (Blender/world) -> Y-up (glTF)
def write(path,z):
    V,F,N,COL,MAT,FLAT=z['V'],z['F'],z['N'],z['COL'],z['MAT'],z['FLAT']
    chunks=[];views=[];acc=[];prims=[];mats=[]
    def add_buf(arr,target):
        b=arr.tobytes(); pad=(-len(b))%4; off=sum(len(c) for c in chunks); chunks.append(b+b'\0'*pad)
        views.append(dict(buffer=0,byteOffset=off,byteLength=len(b),target=target)); return len(views)-1
    for mid,(name,base,met,rough,em) in MATS.items():
        sel=np.nonzero(MAT==mid)[0]
        if len(sel)==0: continue
        Fs=F[sel]; uniq,inv=np.unique(Fs.ravel(),return_inverse=True)
        Vp=to_yup(V[uniq]).astype(np.float32); Fi=inv.reshape(-1,3).astype(np.uint32)
        flat=FLAT[sel].all()
        attrs={}
        def add_acc(arr,ctype,typ,target,minmax=False,norm=False):
            vi=add_buf(arr,target); a=dict(bufferView=vi,componentType=ctype,count=len(arr),type=typ)
            if minmax: a['min']=arr.min(0).tolist(); a['max']=arr.max(0).tolist()
            if norm: a['normalized']=True
            acc.append(a); return len(acc)-1
        attrs['POSITION']=add_acc(Vp,5126,"VEC3",34962,True)
        if not flat: attrs['NORMAL']=add_acc(to_yup(N[uniq]).astype(np.float32),5126,"VEC3",34962)
        col=np.clip(COL[uniq],0,1); col8=np.concatenate([col,np.ones((len(col),1))],1)
        attrs['COLOR_0']=add_acc((col8*255).astype(np.uint8),5121,"VEC4",34962,norm=True)
        idx=add_acc(Fi.ravel(),5125,"SCALAR",34963)
        m=dict(name=name,pbrMetallicRoughness=dict(baseColorFactor=base,metallicFactor=met,roughnessFactor=rough),doubleSided=True)
        if max(em)>0: m['emissiveFactor']=em
        if mid==4: m['extensions']={}
        mats.append(m); prims.append(dict(name=name,primitives=[dict(attributes=attrs,indices=idx,material=len(mats)-1)]))
    meshes=[dict(name=p['name'],primitives=p['primitives']) for p in prims]
    nodes=[dict(name=p['name'],mesh=i) for i,p in enumerate(prims)]
    gltf=dict(asset=dict(version="2.0",generator="C55-C numpy exporter (Claude Sonnet 5.5)"),scene=0,scenes=[dict(nodes=list(range(len(nodes))))],nodes=nodes,meshes=meshes,materials=mats,accessors=acc,bufferViews=views,buffers=[dict(byteLength=sum(len(c) for c in chunks))])
    js=json.dumps(gltf,separators=(',',':')).encode(); js+=b' '*((-len(js))%4); binb=b''.join(chunks)
    out=struct.pack('<III',0x46546C67,2,12+8+len(js)+8+len(binb))+struct.pack('<II',len(js),0x4E4F534A)+js+struct.pack('<II',len(binb),0x004E4942)+binb
    open(path,'wb').write(out); return len(out)
def verify(path):
    d=open(path,'rb').read(); magic,ver,length=struct.unpack('<III',d[:12]); assert magic==0x46546C67 and ver==2 and length==len(d)
    jl,jt=struct.unpack('<II',d[12:20]); g=json.loads(d[20:20+jl]); bo=20+jl; bl,bt=struct.unpack('<II',d[bo:bo+8]); binb=d[bo+8:bo+8+bl]
    ntri=0;bad=0
    for me in g['meshes']:
        for p in me['primitives']:
            ia=g['accessors'][p['indices']]; iv=g['bufferViews'][ia['bufferView']]
            idx=np.frombuffer(binb,np.uint32,ia['count'],iv['byteOffset']); pa=g['accessors'][p['attributes']['POSITION']]; pv=g['bufferViews'][pa['bufferView']]
            pos=np.frombuffer(binb,np.float32,pa['count']*3,pv['byteOffset']).reshape(-1,3)
            assert idx.max()<pa['count'] and np.isfinite(pos).all(); t=idx.reshape(-1,3); ntri+=len(t)
            a=pos[t[:,0]];b=pos[t[:,1]];c=pos[t[:,2]]; bad+=int((np.linalg.norm(np.cross(b-a,c-a),axis=1)<1e-9).sum())
    return dict(header_ok=True,bytes=len(d),meshes=len(g['meshes']),materials=len(g['materials']),triangles=ntri,degenerate_tris=bad)
if __name__=="__main__":
    z=np.load('scene_c55c.npz'); n=write(sys.argv[1],z); print(n/1e6,"MB"); print(verify(sys.argv[1]))
